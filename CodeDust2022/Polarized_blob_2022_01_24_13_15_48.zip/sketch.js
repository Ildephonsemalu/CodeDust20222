function setup() {
  createCanvas(700, 400);
}

function draw() {
  background(0, 126, 255);
  ellipse(190, 150, 150, 200)
  fill(200);
  rect(256, 205, 150, 150 );
  fill(200, 00, 600)
  
}